package com.example.assignment_starbuzz

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
